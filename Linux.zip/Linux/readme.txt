Starfield. Type 'make all', to compile and run starfield.

Requires:
 GNU Make
 Vice
 cl65
 
 This has been adapted by John Lutz
 